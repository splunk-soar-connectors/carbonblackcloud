__all__ = ('language', 'stemmer')

try:
    import Stemmer
    algorithms = Stemmer.algorithms
    stemmer = Stemmer.Stemmer
except ImportError:
    from .arabic_stemmer import ArabicStemmer
    from .armenian_stemmer import ArmenianStemmer
    from .basque_stemmer import BasqueStemmer
    from .catalan_stemmer import CatalanStemmer
    from .czech_stemmer import CzechStemmer
    from .danish_stemmer import DanishStemmer
    from .dutch_porter_stemmer import DutchPorterStemmer
    from .dutch_stemmer import DutchStemmer
    from .english_stemmer import EnglishStemmer
    from .esperanto_stemmer import EsperantoStemmer
    from .estonian_stemmer import EstonianStemmer
    from .finnish_stemmer import FinnishStemmer
    from .french_stemmer import FrenchStemmer
    from .german_stemmer import GermanStemmer
    from .greek_stemmer import GreekStemmer
    from .hindi_stemmer import HindiStemmer
    from .hungarian_stemmer import HungarianStemmer
    from .indonesian_stemmer import IndonesianStemmer
    from .irish_stemmer import IrishStemmer
    from .italian_stemmer import ItalianStemmer
    from .lithuanian_stemmer import LithuanianStemmer
    from .nepali_stemmer import NepaliStemmer
    from .norwegian_stemmer import NorwegianStemmer
    from .persian_stemmer import PersianStemmer
    from .polish_stemmer import PolishStemmer
    from .porter_stemmer import PorterStemmer
    from .portuguese_stemmer import PortugueseStemmer
    from .romanian_stemmer import RomanianStemmer
    from .russian_stemmer import RussianStemmer
    from .serbian_stemmer import SerbianStemmer
    from .sesotho_stemmer import SesothoStemmer
    from .spanish_stemmer import SpanishStemmer
    from .swedish_stemmer import SwedishStemmer
    from .tamil_stemmer import TamilStemmer
    from .turkish_stemmer import TurkishStemmer
    from .yiddish_stemmer import YiddishStemmer

    _languages = {
        'arabic': ArabicStemmer,
        'armenian': ArmenianStemmer,
        'basque': BasqueStemmer,
        'catalan': CatalanStemmer,
        'czech': CzechStemmer,
        'danish': DanishStemmer,
        'dutch': DutchStemmer,
        'dutch_porter': DutchPorterStemmer,
        'english': EnglishStemmer,
        'esperanto': EsperantoStemmer,
        'estonian': EstonianStemmer,
        'finnish': FinnishStemmer,
        'french': FrenchStemmer,
        'german': GermanStemmer,
        'greek': GreekStemmer,
        'hindi': HindiStemmer,
        'hungarian': HungarianStemmer,
        'indonesian': IndonesianStemmer,
        'irish': IrishStemmer,
        'italian': ItalianStemmer,
        'lithuanian': LithuanianStemmer,
        'nepali': NepaliStemmer,
        'norwegian': NorwegianStemmer,
        'persian': PersianStemmer,
        'polish': PolishStemmer,
        'porter': PorterStemmer,
        'portuguese': PortugueseStemmer,
        'romanian': RomanianStemmer,
        'russian': RussianStemmer,
        'serbian': SerbianStemmer,
        'sesotho': SesothoStemmer,
        'spanish': SpanishStemmer,
        'swedish': SwedishStemmer,
        'tamil': TamilStemmer,
        'turkish': TurkishStemmer,
        'yiddish': YiddishStemmer,
    }

    def algorithms():
        return list(_languages.keys())

    def stemmer(lang):
        lang = lang.lower()
        if lang in _languages:
            return _languages[lang]()
        else:
            raise KeyError("Stemming algorithm '%s' not found" % lang)
