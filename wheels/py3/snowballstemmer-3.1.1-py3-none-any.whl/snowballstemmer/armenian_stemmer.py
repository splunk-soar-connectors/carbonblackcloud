# Generated from armenian.sbl by Snowball 3.1.1 - https://snowballstem.org/

from .basestemmer import BaseStemmer
from .among import Among


class ArmenianStemmer(BaseStemmer):
    '''
    This class implements the stemming algorithm defined by a snowball script.
    Generated from armenian.sbl by Snowball 3.1.1 - https://snowballstem.org/
    '''

    g_v = {"ա", "ե", "է", "ը", "ի", "ո", "ւ", "օ"}

    I_p2 = 0
    I_pV = 0

    def __r_mark_regions(self):
        self.I_pV = self.limit
        self.I_p2 = self.limit
        v_1 = self.cursor
        try:
            if not self.go_out_grouping(ArmenianStemmer.g_v):
                raise lab0()
            self.cursor += 1
            self.I_pV = self.cursor
            if not self.go_in_grouping(ArmenianStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_out_grouping(ArmenianStemmer.g_v):
                raise lab0()
            self.cursor += 1
            if not self.go_in_grouping(ArmenianStemmer.g_v):
                raise lab0()
            self.cursor += 1
            self.I_p2 = self.cursor
        except lab0: pass
        self.cursor = v_1
        return True

    def __r_adjective(self):
        self.ket = self.cursor
        if self.find_among_b(ArmenianStemmer.a_0) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        return True

    def __r_verb(self):
        self.ket = self.cursor
        if self.find_among_b(ArmenianStemmer.a_1) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        return True

    def __r_noun(self):
        self.ket = self.cursor
        if self.find_among_b(ArmenianStemmer.a_2) == 0:
            return False
        self.bra = self.cursor
        self.slice_del()
        return True

    def __r_ending(self):
        self.ket = self.cursor
        if self.find_among_b(ArmenianStemmer.a_3) == 0:
            return False
        self.bra = self.cursor
        if self.I_p2 > self.cursor:
            return False
        self.slice_del()
        return True

    def _stem(self):
        self.__r_mark_regions()
        self.limit_backward = self.cursor
        self.cursor = self.limit
        if self.cursor < self.I_pV:
            return False
        v_2 = self.limit_backward
        self.limit_backward = self.I_pV
        v_3 = self.limit - self.cursor
        self.__r_ending()
        self.cursor = self.limit - v_3
        v_4 = self.limit - self.cursor
        self.__r_verb()
        self.cursor = self.limit - v_4
        v_5 = self.limit - self.cursor
        self.__r_adjective()
        self.cursor = self.limit - v_5
        v_6 = self.limit - self.cursor
        self.__r_noun()
        self.cursor = self.limit - v_6
        self.limit_backward = v_2
        self.cursor = self.limit_backward
        return True

    a_0 = [
        Among("րորդ", -1, 1),
        Among("երորդ", 0, 1),
        Among("ալի", -1, 1),
        Among("ակի", -1, 1),
        Among("որակ", -1, 1),
        Among("եղ", -1, 1),
        Among("ական", -1, 1),
        Among("արան", -1, 1),
        Among("են", -1, 1),
        Among("եկեն", 8, 1),
        Among("երեն", 8, 1),
        Among("որէն", -1, 1),
        Among("ին", -1, 1),
        Among("գին", 12, 1),
        Among("ովին", 12, 1),
        Among("լայն", -1, 1),
        Among("վուն", -1, 1),
        Among("պես", -1, 1),
        Among("իվ", -1, 1),
        Among("ատ", -1, 1),
        Among("ավետ", -1, 1),
        Among("կոտ", -1, 1),
        Among("բար", -1, 1)
    ]

    a_1 = [
        Among("ա", -1, 1),
        Among("ացա", 0, 1),
        Among("եցա", 0, 1),
        Among("վե", -1, 1),
        Among("ացրի", -1, 1),
        Among("ացի", -1, 1),
        Among("եցի", -1, 1),
        Among("վեցի", 6, 1),
        Among("ալ", -1, 1),
        Among("ըալ", 8, 1),
        Among("անալ", 8, 1),
        Among("ենալ", 8, 1),
        Among("ացնալ", 8, 1),
        Among("ել", -1, 1),
        Among("ըել", 13, 1),
        Among("նել", 13, 1),
        Among("ցնել", 15, 1),
        Among("եցնել", 16, 1),
        Among("չել", 13, 1),
        Among("վել", 13, 1),
        Among("ացվել", 19, 1),
        Among("եցվել", 19, 1),
        Among("տել", 13, 1),
        Among("ատել", 22, 1),
        Among("ոտել", 22, 1),
        Among("կոտել", 24, 1),
        Among("ված", -1, 1),
        Among("ում", -1, 1),
        Among("վում", 27, 1),
        Among("ան", -1, 1),
        Among("ցան", 29, 1),
        Among("ացան", 30, 1),
        Among("ացրին", -1, 1),
        Among("ացին", -1, 1),
        Among("եցին", -1, 1),
        Among("վեցին", 34, 1),
        Among("ալիս", -1, 1),
        Among("ելիս", -1, 1),
        Among("ավ", -1, 1),
        Among("ացավ", 38, 1),
        Among("եցավ", 38, 1),
        Among("ալով", -1, 1),
        Among("ելով", -1, 1),
        Among("ար", -1, 1),
        Among("ացար", 43, 1),
        Among("եցար", 43, 1),
        Among("ացրիր", -1, 1),
        Among("ացիր", -1, 1),
        Among("եցիր", -1, 1),
        Among("վեցիր", 48, 1),
        Among("աց", -1, 1),
        Among("եց", -1, 1),
        Among("ացրեց", 51, 1),
        Among("ալուց", -1, 1),
        Among("ելուց", -1, 1),
        Among("ալու", -1, 1),
        Among("ելու", -1, 1),
        Among("աք", -1, 1),
        Among("ցաք", 57, 1),
        Among("ացաք", 58, 1),
        Among("ացրիք", -1, 1),
        Among("ացիք", -1, 1),
        Among("եցիք", -1, 1),
        Among("վեցիք", 62, 1),
        Among("անք", -1, 1),
        Among("ցանք", 64, 1),
        Among("ացանք", 65, 1),
        Among("ացրինք", -1, 1),
        Among("ացինք", -1, 1),
        Among("եցինք", -1, 1),
        Among("վեցինք", 69, 1)
    ]

    a_2 = [
        Among("որդ", -1, 1),
        Among("ույթ", -1, 1),
        Among("ուհի", -1, 1),
        Among("ցի", -1, 1),
        Among("իլ", -1, 1),
        Among("ակ", -1, 1),
        Among("յակ", 5, 1),
        Among("անակ", 5, 1),
        Among("իկ", -1, 1),
        Among("ուկ", -1, 1),
        Among("ան", -1, 1),
        Among("պան", 10, 1),
        Among("ստան", 10, 1),
        Among("արան", 10, 1),
        Among("եղէն", -1, 1),
        Among("յուն", -1, 1),
        Among("ություն", 15, 1),
        Among("ածո", -1, 1),
        Among("իչ", -1, 1),
        Among("ուս", -1, 1),
        Among("ուստ", -1, 1),
        Among("գար", -1, 1),
        Among("վոր", -1, 1),
        Among("ավոր", 22, 1),
        Among("ոց", -1, 1),
        Among("անօց", -1, 1),
        Among("ու", -1, 1),
        Among("ք", -1, 1),
        Among("չեք", 27, 1),
        Among("իք", 27, 1),
        Among("ալիք", 29, 1),
        Among("անիք", 29, 1),
        Among("վածք", 27, 1),
        Among("ույք", 27, 1),
        Among("ենք", 27, 1),
        Among("ոնք", 27, 1),
        Among("ունք", 27, 1),
        Among("մունք", 36, 1),
        Among("իչք", 27, 1),
        Among("արք", 27, 1)
    ]

    a_3 = [
        Among("սա", -1, 1),
        Among("վա", -1, 1),
        Among("ամբ", -1, 1),
        Among("դ", -1, 1),
        Among("անդ", 3, 1),
        Among("ությանդ", 4, 1),
        Among("վանդ", 4, 1),
        Among("ոջդ", 3, 1),
        Among("երդ", 3, 1),
        Among("ներդ", 8, 1),
        Among("ուդ", 3, 1),
        Among("ը", -1, 1),
        Among("անը", 11, 1),
        Among("ությանը", 12, 1),
        Among("վանը", 12, 1),
        Among("ոջը", 11, 1),
        Among("երը", 11, 1),
        Among("ները", 16, 1),
        Among("ի", -1, 1),
        Among("վի", 18, 1),
        Among("երի", 18, 1),
        Among("ների", 20, 1),
        Among("անում", -1, 1),
        Among("երում", -1, 1),
        Among("ներում", 23, 1),
        Among("ն", -1, 1),
        Among("ան", 25, 1),
        Among("ության", 26, 1),
        Among("վան", 26, 1),
        Among("ին", 25, 1),
        Among("երին", 29, 1),
        Among("ներին", 30, 1),
        Among("ությանն", 25, 1),
        Among("երն", 25, 1),
        Among("ներն", 33, 1),
        Among("ուն", 25, 1),
        Among("ոջ", -1, 1),
        Among("ությանս", -1, 1),
        Among("վանս", -1, 1),
        Among("ոջս", -1, 1),
        Among("ով", -1, 1),
        Among("անով", 40, 1),
        Among("վով", 40, 1),
        Among("երով", 40, 1),
        Among("ներով", 43, 1),
        Among("եր", -1, 1),
        Among("ներ", 45, 1),
        Among("ց", -1, 1),
        Among("ից", 47, 1),
        Among("վանից", 48, 1),
        Among("ոջից", 48, 1),
        Among("վից", 48, 1),
        Among("երից", 48, 1),
        Among("ներից", 52, 1),
        Among("ցից", 48, 1),
        Among("ոց", 47, 1),
        Among("ուց", 47, 1)
    ]


class lab0(BaseException): pass
